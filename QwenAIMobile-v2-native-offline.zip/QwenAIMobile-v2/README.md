# Qwen AI Mobile v2 — native offline runtime

This version upgrades the v1 client into a native Android architecture:

```text
Jetpack Compose
      |
 Kotlin model manager
      |
 JNI
      |
 llama.cpp / ggml
      |
 Qwen3 GGUF
```

## Included

- Native `arm64-v8a` target
- Android NDK/CMake integration
- JNI bridge
- GGUF model importer into app-private storage
- native model load/unload
- persistent chat
- Qwen/OpenAI-compatible server fallback
- model and system-prompt settings

## Build the native runtime

The repository expects the official llama.cpp source at:

`app/src/main/cpp/llama.cpp`

Run:

```bash
./scripts/sync_llama.sh
```

Then open in Android Studio and build.

The script intentionally clones the current upstream `ggml-org/llama.cpp` rather than copying a stale snapshot into the project.

## Model

For a practical phone test, use a Qwen3 GGUF quantization appropriate for the device. Qwen's current llama.cpp guide provides official GGUFs and shows Qwen3-8B Q4_K_M as an example. See the official Qwen documentation.

Do NOT bundle an 8B+ model into the APK. Import the `.gguf` file through the app's **Modell** button. This keeps the APK manageable and permits model replacement.

## Runtime

The JNI layer currently handles model lifecycle. The next native inference layer should bind llama.cpp's sampler/context APIs and expose token streaming to Kotlin. Keeping the JNI boundary small makes upgrades against upstream llama.cpp much easier.

## Performance

Start with a 4096-token context on a phone. Memory use rises with context and model size. The exact model/quantization should be selected according to available RAM and thermal limits.

## Official upstream references

Qwen3 + llama.cpp:
https://github.com/QwenLM/Qwen3/blob/main/docs/source/run_locally/llama.cpp.md

llama.cpp Android:
https://github.com/ggml-org/llama.cpp/tree/master/examples/llama.android
