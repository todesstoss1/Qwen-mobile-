#include <jni.h>
#include <string>
#include <mutex>

#if __has_include("llama.h")
#include "llama.h"
#define QWEN_LLAMA_AVAILABLE 1
#else
#define QWEN_LLAMA_AVAILABLE 0
#endif

static std::mutex g_mutex;
static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_qwenmobile_ai_NativeQwen_nativeAvailable(JNIEnv*, jobject) {
#if QWEN_LLAMA_AVAILABLE
    return JNI_TRUE;
#else
    return JNI_FALSE;
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_qwenmobile_ai_NativeQwen_nativeVersion(JNIEnv* env, jobject) {
#if QWEN_LLAMA_AVAILABLE
    return env->NewStringUTF(llama_version());
#else
    return env->NewStringUTF("llama.cpp not linked");
#endif
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_qwenmobile_ai_NativeQwen_nativeLoad(JNIEnv* env, jobject, jstring path, jint contextSize) {
#if QWEN_LLAMA_AVAILABLE
    const char* p = env->GetStringUTFChars(path, nullptr);
    std::lock_guard<std::mutex> lock(g_mutex);

    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }

    llama_model_params mp = llama_model_default_params();
    g_model = llama_model_load_from_file(p, mp);
    env->ReleaseStringUTFChars(path, p);
    if (!g_model) return JNI_FALSE;

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = static_cast<uint32_t>(contextSize);
    cp.n_threads = 4;
    cp.n_threads_batch = 4;
    g_ctx = llama_init_from_model(g_model, cp);

    if (!g_ctx) {
        llama_model_free(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }
    return JNI_TRUE;
#else
    return JNI_FALSE;
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_qwenmobile_ai_NativeQwen_nativeUnload(JNIEnv*, jobject) {
#if QWEN_LLAMA_AVAILABLE
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
#endif
}
