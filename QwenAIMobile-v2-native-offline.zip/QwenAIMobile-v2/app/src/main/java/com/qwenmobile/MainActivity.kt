package com.qwenmobile

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qwenmobile.ai.QwenClient
import com.qwenmobile.ai.NativeQwen
import com.qwenmobile.ai.ModelManager
import java.io.File
import com.qwenmobile.data.ChatMessage
import com.qwenmobile.data.ChatStore
import com.qwenmobile.data.SettingsStore
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QwenMobileApp(this) }
    }
}

@Composable
fun QwenMobileApp(context: Context) {
    val settings = remember { SettingsStore(context) }
    val store = remember { ChatStore(context) }
    val scope = rememberCoroutineScope()
    var messages by remember { mutableStateOf(store.load()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var endpoint by remember { mutableStateOf(settings.endpoint) }
    var model by remember { mutableStateOf(settings.model) }
    var systemPrompt by remember { mutableStateOf(settings.systemPrompt) }
    var showSettings by remember { mutableStateOf(false) }
    var localModel by remember { mutableStateOf<File?>(null) }
    var localReady by remember { mutableStateOf(false) }
    val modelManager = remember { ModelManager(context) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            status = "Modell wird importiert…"
            runCatching { modelManager.import(uri) }
                .onSuccess { localModel = it; status = "Modell importiert" }
                .onFailure { status = "Import fehlgeschlagen: ${it.message}" }
        }
    }
    var status by remember { mutableStateOf("Bereit") }
    val list = rememberLazyListState()

    MaterialTheme(colorScheme = darkColorScheme()) {
        if (showSettings) {
            SettingsScreen(
                endpoint = endpoint,
                model = model,
                systemPrompt = systemPrompt,
                onEndpoint = { endpoint = it; settings.endpoint = it },
                onModel = { model = it; settings.model = it },
                onPrompt = { systemPrompt = it; settings.systemPrompt = it },
                onBack = { showSettings = false }
            )
        } else {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Qwen AI Mobile") },
                        actions = {
                            TextButton(onClick = { showSettings = true }) { Text("⚙") }
                            TextButton(onClick = { picker.launch(arrayOf("application/octet-stream", "*/*")) }) { Text("Modell") }
                            TextButton(onClick = {
                                messages = emptyList()
                                store.save(messages)
                            }) { Text("Neu") }
                        }
                    )
                }
            ) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad)
                ) {
                    if (localModel != null) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Lokal: ${localModel!!.name}", Modifier.weight(1f), fontSize = 12.sp)
                            Button(onClick = {
                                localReady = NativeQwen.loadModel(localModel!!.absolutePath, 4096)
                                status = if (localReady) "Qwen lokal geladen (${runCatching { NativeQwen.nativeVersion() }.getOrDefault("native")})" else "Lokales Laden fehlgeschlagen"
                            }) { Text(if (localReady) "Geladen" else "Start") }
                        }
                    }

                    LazyColumn(
                        state = list,
                        modifier = Modifier.weight(1f).fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(messages) { msg ->
                            MessageBubble(msg)
                        }
                    }

                    Text(
                        status,
                        modifier = Modifier.padding(horizontal = 16.dp),
                        fontSize = 12.sp
                    )

                    Row(
                        Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Nachricht an Qwen…") },
                            maxLines = 5
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            enabled = input.isNotBlank() && !busy,
                            onClick = {
                                val text = input.trim()
                                input = ""
                                messages = messages + ChatMessage("user", text)
                                store.save(messages)
                                busy = true
                                status = "Qwen denkt…"
                                scope.launch {
                                    val result = QwenClient.chat(
                                        endpoint = endpoint,
                                        model = model,
                                        systemPrompt = systemPrompt,
                                        history = messages
                                    )
                                    messages = messages + ChatMessage("assistant", result)
                                    store.save(messages)
                                    busy = false
                                    status = "Bereit"
                                }
                            }
                        ) { Text("Senden") }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val user = message.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            tonalElevation = 2.dp,
            shape = MaterialTheme.shapes.large,
            modifier = Modifier.widthIn(max = 360.dp)
        ) {
            Text(
                message.content,
                Modifier.padding(14.dp),
                fontSize = 16.sp
            )
        }
    }
}

@Composable
private fun SettingsScreen(
    endpoint: String,
    model: String,
    systemPrompt: String,
    onEndpoint: (String) -> Unit,
    onModel: (String) -> Unit,
    onPrompt: (String) -> Unit,
    onBack: () -> Unit
) {
    var ep by remember(endpoint) { mutableStateOf(endpoint) }
    var mo by remember(model) { mutableStateOf(model) }
    var sp by remember(systemPrompt) { mutableStateOf(systemPrompt) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Qwen Einstellungen") },
                navigationIcon = { TextButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Inference-Server", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                ep, { ep = it; onEndpoint(it) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("OpenAI-kompatibler Endpoint") }
            )
            OutlinedTextField(
                mo, { mo = it; onModel(it) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Modellname") }
            )
            OutlinedTextField(
                sp, { sp = it; onPrompt(it) },
                modifier = Modifier.fillMaxWidth().height(180.dp),
                label = { Text("System Prompt") }
            )
            Text(
                "Für lokale Ausführung: llama-server auf dem Gerät/Netz starten und diesen Endpoint eintragen. Die App verwendet /v1/chat/completions.",
                fontSize = 13.sp
            )
        }
    }
}
