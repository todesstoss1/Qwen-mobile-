package com.qwenmobile.ai

import android.content.Context
import android.net.Uri
import java.io.File

class ModelManager(private val context: Context) {
    private val dir: File = File(context.filesDir, "models").apply { mkdirs() }

    fun list(): List<File> =
        dir.listFiles()?.filter { it.extension.equals("gguf", true) }?.sortedBy { it.name } ?: emptyList()

    fun import(uri: Uri): File {
        val name = "model_${System.currentTimeMillis()}.gguf"
        val out = File(dir, name)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open model" }
            out.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
        }
        return out
    }

    fun delete(file: File) {
        file.delete()
    }
}
