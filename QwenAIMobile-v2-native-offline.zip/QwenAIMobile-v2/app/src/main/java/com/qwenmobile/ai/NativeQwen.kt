package com.qwenmobile.ai

object NativeQwen {
    private var loaded = false

    init {
        runCatching { System.loadLibrary("qwenmobile") }
    }

    external fun nativeAvailable(): Boolean
    external fun nativeVersion(): String
    external fun nativeLoad(path: String, contextSize: Int): Boolean
    external fun nativeUnload()

    fun loadModel(path: String, contextSize: Int = 4096): Boolean {
        loaded = runCatching { nativeLoad(path, contextSize) }.getOrDefault(false)
        return loaded
    }

    fun unload() {
        if (loaded) runCatching { nativeUnload() }
        loaded = false
    }
}
