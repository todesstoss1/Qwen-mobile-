package com.qwenmobile.ai

import com.qwenmobile.data.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI

object QwenClient {
    suspend fun chat(
        endpoint: String,
        model: String,
        systemPrompt: String,
        history: List<ChatMessage>
    ): String = withContext(Dispatchers.IO) {
        val url = URI(endpoint.trimEnd('/') + "/v1/chat/completions").toURL()
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15_000
        conn.readTimeout = 180_000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        history.forEach {
            messages.put(JSONObject().put("role", it.role).put("content", it.content))
        }

        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.7)
            .put("stream", false)

        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
            .bufferedReader().use { it.readText() }

        if (code !in 200..299) {
            return@withContext "Fehler $code: $text"
        }

        runCatching {
            JSONObject(text)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        }.getOrElse { "Ungültige Serverantwort: $text" }
    }
}
