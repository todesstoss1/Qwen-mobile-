package com.qwenmobile.data

data class ChatMessage(
    val role: String,
    val content: String
)
