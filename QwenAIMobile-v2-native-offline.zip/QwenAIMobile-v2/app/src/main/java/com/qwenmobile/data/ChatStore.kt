package com.qwenmobile.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ChatStore(context: Context) {
    private val prefs = context.getSharedPreferences("chat", Context.MODE_PRIVATE)

    fun load(): List<ChatMessage> {
        return runCatching {
            val a = JSONArray(prefs.getString("messages", "[]"))
            buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(ChatMessage(o.getString("role"), o.getString("content")))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(messages: List<ChatMessage>) {
        val a = JSONArray()
        messages.forEach {
            a.put(JSONObject().apply {
                put("role", it.role)
                put("content", it.content)
            })
        }
        prefs.edit().putString("messages", a.toString()).apply()
    }
}
