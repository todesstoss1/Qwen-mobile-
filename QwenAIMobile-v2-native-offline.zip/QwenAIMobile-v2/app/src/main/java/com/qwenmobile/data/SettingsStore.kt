package com.qwenmobile.data

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var endpoint: String
        get() = prefs.getString("endpoint", "http://127.0.0.1:8080") ?: ""
        set(v) { prefs.edit().putString("endpoint", v).apply() }

    var model: String
        get() = prefs.getString("model", "qwen") ?: "qwen"
        set(v) { prefs.edit().putString("model", v).apply() }

    var systemPrompt: String
        get() = prefs.getString(
            "systemPrompt",
            "You are Qwen, a helpful, accurate and concise AI assistant. Answer in the user's language."
        ) ?: ""
        set(v) { prefs.edit().putString("systemPrompt", v).apply() }
}
