#!/usr/bin/env bash
set -euo pipefail

# Builds the current upstream llama.cpp Android artifacts.
# Run from a Linux/macOS development machine with Android SDK/NDK installed.

: "${ANDROID_NDK:?Set ANDROID_NDK to your Android NDK directory}"

git clone --depth 1 https://github.com/ggml-org/llama.cpp third_party/llama.cpp || true

cmake -S third_party/llama.cpp -B third_party/llama.cpp/build-android \
  -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-28 \
  -DBUILD_SHARED_LIBS=OFF \
  -DGGML_OPENMP=OFF \
  -DGGML_NATIVE=OFF

cmake --build third_party/llama.cpp/build-android --config Release -j"$(nproc)"

echo "llama.cpp Android build complete."
