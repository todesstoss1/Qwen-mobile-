#!/usr/bin/env bash
set -euo pipefail
DEST="$(cd "$(dirname "$0")/.." && pwd)/app/src/main/cpp/llama.cpp"
mkdir -p "$(dirname "$DEST")"
if [ -d "$DEST/.git" ]; then
  git -C "$DEST" fetch --depth 1 origin master
  git -C "$DEST" reset --hard origin/master
else
  git clone --depth 1 https://github.com/ggml-org/llama.cpp "$DEST"
fi
echo "Synced llama.cpp into $DEST"
